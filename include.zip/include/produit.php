<html>
<head>
    <?php
    include 'parts/global-stylesheets.php';
    ?>
</head>
<body>

<div class="container">
    <?php
    include 'parts/menu.php'
    ?>

    <h1>Mon produit ! </h1>

    <h2>Les 3 produits les plus vendu</h2>
    <div class="row">
    <?php
        for($i=0; $i<3;$i++){

            include 'parts/product-mignature.php';
        }

    ?>
    </div>
</div>



<?php
include 'parts/footer.php';
include 'parts/global-scripts.php';
?>
</body>
</html>