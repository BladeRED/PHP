<html>
<head>
    <?php
        include 'parts/global-stylesheets.php';
    ?>
</head>
<body>

<div class="container">
<?php
 include 'parts/menu.php'
?>


<div class="row">
<?php
    for($i=0; $i<100; $i++){
        include 'parts/product-mignature.php';
    }
?>
</div>

</div>
<?php
    include 'parts/footer.php';
    include 'parts/global-scripts.php';
?>
</body>
</html>