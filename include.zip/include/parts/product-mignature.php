<div class="col-md-3">
<div class="card" style="width: 18rem;">
    <img class="card-img-top" src="https://cdn.futura-sciences.com/buildsv6/images/largeoriginal/8/5/8/858743bb35_50169458_chien-min.jpg" alt="Card image cap">
    <div class="card-body">
        <h5 class="card-title">Lorem ... </h5>
        <p class="card-text">On est vendredi on parle pas animalerie !</p>
        <a href="#" class="btn btn-primary">Go somewhere</a>
    </div>
</div>
</div>

